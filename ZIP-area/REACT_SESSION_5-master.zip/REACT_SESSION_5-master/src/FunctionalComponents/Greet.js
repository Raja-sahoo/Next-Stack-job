import React from "react"

function Greet(){
  return(
    <h1>Good Evening Everyone</h1>
  )
}
 export default Greet